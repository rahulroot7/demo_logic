<?php
namespace Aws\MachineLearning\Exception;

use Aws\Exception\AwsException;

/**
 * Amazon Machine Learning exception.
 */
class MachineLearningException extends AwsException {}
