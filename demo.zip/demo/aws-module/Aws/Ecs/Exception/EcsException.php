<?php
namespace Aws\Ecs\Exception;

use Aws\Exception\AwsException;

/**
 * Amazon ECS exception.
 */
class EcsException extends AwsException {}
