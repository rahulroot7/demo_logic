<?php
// This file was auto-generated from sdk-root/src/data/cloudfront/2018-11-05/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'ListCloudFrontOriginAccessIdentities', 'input' => [ 'MaxItems' => '1', ], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetDistribution', 'input' => [ 'Id' => 'fake-id', ], 'errorExpectedFromService' => true, ], ],];
